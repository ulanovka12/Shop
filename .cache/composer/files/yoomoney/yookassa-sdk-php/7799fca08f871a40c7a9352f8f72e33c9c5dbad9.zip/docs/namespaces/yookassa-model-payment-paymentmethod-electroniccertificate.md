# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Model\Payment\PaymentMethod\ElectronicCertificate

## Parent: [\YooKassa\Model\Payment\PaymentMethod](../namespaces/yookassa-model-payment-paymentmethod.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Model\Payment\PaymentMethod\ElectronicCertificate\ElectronicCertificate](../classes/YooKassa-Model-Payment-PaymentMethod-ElectronicCertificate-ElectronicCertificate.md) | Класс, представляющий модель ElectronicCertificate. |
| [\YooKassa\Model\Payment\PaymentMethod\ElectronicCertificate\ElectronicCertificateApprovedPaymentArticle](../classes/YooKassa-Model-Payment-PaymentMethod-ElectronicCertificate-ElectronicCertificateApprovedPaymentArticle.md) | Класс, представляющий модель ElectronicCertificateApprovedPaymentArticle. |
| [\YooKassa\Model\Payment\PaymentMethod\ElectronicCertificate\ElectronicCertificatePaymentData](../classes/YooKassa-Model-Payment-PaymentMethod-ElectronicCertificate-ElectronicCertificatePaymentData.md) | Класс, представляющий модель ElectronicCertificatePaymentData. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-10-06 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney