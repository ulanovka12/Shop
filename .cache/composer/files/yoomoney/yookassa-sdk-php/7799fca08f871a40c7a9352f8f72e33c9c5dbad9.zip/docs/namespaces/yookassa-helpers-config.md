# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Helpers\Config

## Parent: [\YooKassa\Helpers](../namespaces/yookassa-helpers.md)

### Interfaces

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Helpers\Config\ConfigurationLoaderInterface](../classes/YooKassa-Helpers-Config-ConfigurationLoaderInterface.md) | Interface ConfigurationLoaderInterface. |

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Helpers\Config\ConfigurationLoader](../classes/YooKassa-Helpers-Config-ConfigurationLoader.md) | Класс, представляющий модель ConfigurationLoader. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-10-06 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney