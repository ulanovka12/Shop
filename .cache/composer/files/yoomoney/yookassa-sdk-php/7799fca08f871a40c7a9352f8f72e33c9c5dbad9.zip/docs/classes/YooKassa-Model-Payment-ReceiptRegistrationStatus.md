# [YooKassa API SDK](../home.md)

# Class: \YooKassa\Model\Payment\ReceiptRegistrationStatus
### Namespace: [\YooKassa\Model\Payment](../namespaces/yookassa-model-payment.md)
---
**Summary:**

Класс, представляющий модель ReceiptRegistrationStatus.

**Description:**

Возможные статусы доставки данных для чека в онлайн-кассу.

Состояние регистрации фискального чека:
- `pending` - Чек ожидает доставки
- `succeeded` - Успешно доставлен
- `canceled` - Чек не доставлен

---
### Constants
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [PENDING](../classes/YooKassa-Model-Payment-ReceiptRegistrationStatus.md#constant_PENDING) |  | Состояние регистрации фискального чека: ожидает доставки |
| public | [SUCCEEDED](../classes/YooKassa-Model-Payment-ReceiptRegistrationStatus.md#constant_SUCCEEDED) |  | Состояние регистрации фискального чека: успешно доставлен |
| public | [CANCELED](../classes/YooKassa-Model-Payment-ReceiptRegistrationStatus.md#constant_CANCELED) |  | Состояние регистрации фискального чека: не доставлен |
| public | [UNKNOWN](../classes/YooKassa-Model-Payment-ReceiptRegistrationStatus.md#constant_UNKNOWN) |  | Состояние регистрации фискального чека не известно. |

---
### Properties
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| protected | [$validValues](../classes/YooKassa-Model-Payment-ReceiptRegistrationStatus.md#property_validValues) |  |  |

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [getEnabledValues()](../classes/YooKassa-Common-AbstractEnum.md#method_getEnabledValues) |  | Возвращает значения в enum'е значения которых разрешены. |
| public | [getValidValues()](../classes/YooKassa-Common-AbstractEnum.md#method_getValidValues) |  | Возвращает все значения в enum'e. |
| public | [valueExists()](../classes/YooKassa-Common-AbstractEnum.md#method_valueExists) |  | Проверяет наличие значения в enum'e. |

---
### Details
* File: [lib/Model/Payment/ReceiptRegistrationStatus.php](../../lib/Model/Payment/ReceiptRegistrationStatus.php)
* Package: YooKassa\Model
* Class Hierarchy: 
  * [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)
  * \YooKassa\Model\Payment\ReceiptRegistrationStatus

* See Also:
  * [](https://yookassa.ru/developers/api)

---
### Tags
| Tag | Version | Description |
| --- | ------- | ----------- |
| category |  | Class |
| author |  | cms@yoomoney.ru |

---
## Constants
<a name="constant_PENDING" class="anchor"></a>
###### PENDING
Состояние регистрации фискального чека: ожидает доставки

```php
PENDING = 'pending'
```


<a name="constant_SUCCEEDED" class="anchor"></a>
###### SUCCEEDED
Состояние регистрации фискального чека: успешно доставлен

```php
SUCCEEDED = 'succeeded'
```


<a name="constant_CANCELED" class="anchor"></a>
###### CANCELED
Состояние регистрации фискального чека: не доставлен

```php
CANCELED = 'canceled'
```


<a name="constant_UNKNOWN" class="anchor"></a>
###### UNKNOWN
Состояние регистрации фискального чека не известно.

```php
UNKNOWN = 'unknown'
```



---
## Properties
<a name="property_validValues"></a>
#### protected $validValues : array
---
**Type:** <a href="../array"><abbr title="array">array</abbr></a>
Массив принимаемых enum&#039;ом значений
**Details:**



---
## Methods
<a name="method_getEnabledValues" class="anchor"></a>
#### public getEnabledValues() : string[]

```php
Static public getEnabledValues() : string[]
```

**Summary**

Возвращает значения в enum'е значения которых разрешены.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

**Returns:** string[] - Массив разрешённых значений


<a name="method_getValidValues" class="anchor"></a>
#### public getValidValues() : array

```php
Static public getValidValues() : array
```

**Summary**

Возвращает все значения в enum'e.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

**Returns:** array - Массив значений в перечислении


<a name="method_valueExists" class="anchor"></a>
#### public valueExists() : bool

```php
Static public valueExists(mixed $value) : bool
```

**Summary**

Проверяет наличие значения в enum'e.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">mixed</code> | value  | Проверяемое значение |

**Returns:** bool - True если значение имеется, false если нет



---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-10-06 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney