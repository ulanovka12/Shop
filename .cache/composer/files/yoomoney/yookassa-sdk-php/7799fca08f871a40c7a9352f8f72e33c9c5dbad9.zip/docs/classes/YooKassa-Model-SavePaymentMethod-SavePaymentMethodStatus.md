# [YooKassa API SDK](../home.md)

# Class: \YooKassa\Model\SavePaymentMethod\SavePaymentMethodStatus
### Namespace: [\YooKassa\Model\SavePaymentMethod](../namespaces/yookassa-model-savepaymentmethod.md)
---
**Summary:**

Класс, представляющий модель SavePaymentMethodStatus.

**Description:**

Статус проверки и сохранения способа оплаты. Возможные значения:
~`pending` — ожидает действий от пользователя;
~`active` — способ оплаты сохранен, его можно использовать для автоплатежей или выплат(для выплат можно сохранить только [банковскую карту](/developers/payouts/scenario-extensions/multipurpose-token));
~`inactive` — способ оплаты не сохранен: пользователь не подтвердил привязку платежного средства или при сохранении способа оплаты возникла ошибка. Чтобы узнать подробности, обратитесь в техническую поддержку ЮKassa.

---
### Constants
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [PENDING](../classes/YooKassa-Model-SavePaymentMethod-SavePaymentMethodStatus.md#constant_PENDING) |  | Ожидает действий от пользователя |
| public | [ACTIVE](../classes/YooKassa-Model-SavePaymentMethod-SavePaymentMethodStatus.md#constant_ACTIVE) |  |  |
| public | [INACTIVE](../classes/YooKassa-Model-SavePaymentMethod-SavePaymentMethodStatus.md#constant_INACTIVE) |  | Способ оплаты не сохранен: пользователь не подтвердил привязку платежного средства или при сохранении способа оплаты возникла ошибка. Чтобы узнать подробности, обратитесь в техническую поддержку ЮKassa. |
| public | [UNKNOWN](../classes/YooKassa-Model-SavePaymentMethod-SavePaymentMethodStatus.md#constant_UNKNOWN) |  | Статус проверки и сохранения способа оплаты не известен. |

---
### Properties
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| protected | [$validValues](../classes/YooKassa-Model-SavePaymentMethod-SavePaymentMethodStatus.md#property_validValues) |  | Возвращает список доступных значений |

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [getEnabledValues()](../classes/YooKassa-Common-AbstractEnum.md#method_getEnabledValues) |  | Возвращает значения в enum'е значения которых разрешены. |
| public | [getValidValues()](../classes/YooKassa-Common-AbstractEnum.md#method_getValidValues) |  | Возвращает все значения в enum'e. |
| public | [valueExists()](../classes/YooKassa-Common-AbstractEnum.md#method_valueExists) |  | Проверяет наличие значения в enum'e. |

---
### Details
* File: [lib/Model/SavePaymentMethod/SavePaymentMethodStatus.php](../../lib/Model/SavePaymentMethod/SavePaymentMethodStatus.php)
* Package: YooKassa\Model
* Class Hierarchy: 
  * [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)
  * \YooKassa\Model\SavePaymentMethod\SavePaymentMethodStatus

* See Also:
  * [](https://yookassa.ru/developers/api)

---
### Tags
| Tag | Version | Description |
| --- | ------- | ----------- |
| category |  | Class |
| author |  | cms@yoomoney.ru |

---
## Constants
<a name="constant_PENDING" class="anchor"></a>
###### PENDING
Ожидает действий от пользователя

```php
PENDING = 'pending'
```


<a name="constant_ACTIVE" class="anchor"></a>
###### ACTIVE
```php
ACTIVE = 'active'
```


<a name="constant_INACTIVE" class="anchor"></a>
###### INACTIVE
Способ оплаты не сохранен: пользователь не подтвердил привязку платежного средства или при сохранении способа оплаты возникла ошибка. Чтобы узнать подробности, обратитесь в техническую поддержку ЮKassa.

```php
INACTIVE = 'inactive'
```


<a name="constant_UNKNOWN" class="anchor"></a>
###### UNKNOWN
Статус проверки и сохранения способа оплаты не известен.

```php
UNKNOWN = 'unknown'
```



---
## Properties
<a name="property_validValues"></a>
#### protected $validValues : array
---
**Summary**

Возвращает список доступных значений

**Type:** <a href="../array"><abbr title="array">array</abbr></a>
Массив принимаемых enum&#039;ом значений
**Details:**


##### Tags
| Tag | Version | Description |
| --- | ------- | ----------- |
| return |  |  |


---
## Methods
<a name="method_getEnabledValues" class="anchor"></a>
#### public getEnabledValues() : string[]

```php
Static public getEnabledValues() : string[]
```

**Summary**

Возвращает значения в enum'е значения которых разрешены.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

**Returns:** string[] - Массив разрешённых значений


<a name="method_getValidValues" class="anchor"></a>
#### public getValidValues() : array

```php
Static public getValidValues() : array
```

**Summary**

Возвращает все значения в enum'e.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

**Returns:** array - Массив значений в перечислении


<a name="method_valueExists" class="anchor"></a>
#### public valueExists() : bool

```php
Static public valueExists(mixed $value) : bool
```

**Summary**

Проверяет наличие значения в enum'e.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractEnum](../classes/YooKassa-Common-AbstractEnum.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">mixed</code> | value  | Проверяемое значение |

**Returns:** bool - True если значение имеется, false если нет



---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-10-06 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney